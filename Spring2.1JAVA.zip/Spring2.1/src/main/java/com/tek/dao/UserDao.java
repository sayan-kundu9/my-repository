package com.tek.dao;

import java.util.List;

import com.tek.model.Login;
import com.tek.model.User;

public interface UserDao {

	void register(User user);
	
	User validateUser(Login login);
	
	public List<User> getUsers();
	
	public void delete(String username);
	
	public void update(User user);
	public User getUserByUsername(String username);
}
