/*package com.tek.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import com.tek.model.Login;
import com.tek.model.User;

public class UserDaoImpl implements UserDao {

	@Autowired
	DataSource datasource;
	
	@Autowired
	JdbcTemplate jdbcTemplate;

	public void register(User user) {
		String sql = "insert into users values(?,?,?,?,?,?,?)";
		String sql2 = "insert into users2 values(?,?,?,?,?,?,?)";
		
		
		jdbcTemplate.update(sql2, new Object[] { user.getUsername(), user.getPassword(), user.getFirstname(),
			    user.getLastname(), user.getEmail(), user.getAddress(), user.getPhone() });
		
		//String s = user.getPhone().replaceAll("[^\\d.]", "");;
		
		
		
		
		jdbcTemplate.update(sql, new Object[] { user.getUsername(), user.getPassword(), user.getFirstname(),
			    user.getLastname(), user.getEmail(), user.getAddress(), user.getPhone().replaceAll("[^\\d.]", "") });
		
		
		
	}

	public User validateUser(Login login) {
		String sql = "select * from users where username='" + login.getUsername() + "' and password='" + login.getPassword()
	    + "'";
		
		List<User> users = jdbcTemplate.query(sql, new UserMapper());
		return users.size()> 0 ? users.get(0) : null;
	}

	public List<User> getUsers() {
		String sql = "select * from users";
		return jdbcTemplate.query(sql, new RowMapper<User>() {

			public User mapRow(ResultSet rs, int arg1) throws SQLException {
				
				User u = new User();
				u.setUsername(rs.getString(1));
				u.setPassword(rs.getString(2));
				u.setFirstname(rs.getString(3));
				u.setLastname(rs.getString(4));
				u.setEmail(rs.getString(5));
				u.setAddress(rs.getString(6));
				u.setPhone(rs.getString(7));
				
				return u;
			}
			
		});
	}

	public void delete(String username) {
		String sql="delete from users where username=?";  
		String sql2="delete from users2 where username=?";
	     jdbcTemplate.update(sql , new Object[] {username});
	     jdbcTemplate.update(sql2 , new Object[] {username});
		
	}

	public void update(User user) {
		String sql="update users set username = ?, password = ?, firstname = ?, lastname = ?, email = ?, address = ?, phone= ? where username = ?" ;
		String sql2="update users2 set username = ?, password = ?, firstname = ?, lastname = ?, email = ?, address = ?, phone= ? where username = ?" ;
		
		jdbcTemplate.update(sql, new Object[] { user.getUsername(), user.getPassword(), user.getFirstname(),
			    user.getLastname(), user.getEmail(), user.getAddress(), user.getPhone(), user.getUsername() });
		
		
		jdbcTemplate.update(sql2, new Object[] { user.getUsername(), user.getPassword(), user.getFirstname(),
			    user.getLastname(), user.getEmail(), user.getAddress(), user.getPhone(), user.getUsername() });
		
		public void updateStudent(Student student) {
			String sql = "update student set username=?, password=?, address=?, gender=?, phone=?,department=? where username=?";
			jdbctemplate.update(sql, new Object[] { student.getUsername(), student.getPassword(), student.getAddress(),
					student.getGender(), student.getPhone(), student.getDepartment(), student.getUsername() });
		
	}

	public User getUserByUsername(String username) {
		String sql="select * from users where username=?";  
	    return jdbcTemplate.queryForObject(sql, new Object[]{username},new BeanPropertyRowMapper<User>(User.class));  
	}

}
*/